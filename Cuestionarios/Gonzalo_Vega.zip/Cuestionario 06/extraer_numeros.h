#ifndef EXTRAER_NUMEROS_H
#define EXTRAER_NUMEROS_H
funcion entero cadenaAEntero(cadena);
funcion entero cadenaAReal(cadena);
#endif
