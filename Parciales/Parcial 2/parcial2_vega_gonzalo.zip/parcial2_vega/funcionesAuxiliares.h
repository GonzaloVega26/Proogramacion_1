#ifndef FUNCIONESAUXILIARES_H
#define FUNCIONESAUXILIARES_H
funcion vectorDin(entero) cargarDatosVector(vectorDin(entero));
funcion vectorDin(entero) eliminarDuplicados(vectorDin(entero));
procedimiento mostrarVector(vectorDin(entero));
funcion entero sumarElementosVector(vectorDin(entero));
funcion vectorDin(entero) interseccionDeVectores(vectorDin(entero), vectorDin(entero));
#endif
